export interface Car {
  model: string;
  price: number;
  id?: number;
}
